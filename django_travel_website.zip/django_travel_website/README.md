# django_travel_website
Travel website with Python Django

A guest user could:
       view the packages
       contact the admin
       Register and sign in
       
 Registered uers could:
       view the travel packages,itinerary and payment
       also contact admin/company or any queries or additional trip packages
       can select convinent packages and payment canbe done.(due to security reasons payment page is just a demo)
       
 Admin could:
 create new travel packages,update or delete existing packages
 go through customer queries in the admin page.
 go throught the registered users,deleteor add new users according to the needs
 
 
 
 Template inspired from w3schools templates snowboarding, monster templates and youtube channels.
 
 
 
 
 
       
  
       
       
